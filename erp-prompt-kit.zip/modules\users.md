### User Management (`users`) — CORE
- **Depends on:** platform auth
- **Default roles:** owner, gm
- **Features:** see Section 5 ("User admin screen").
- **Extras**
  - Rename cascade for printed snapshots.
  - HR/payroll fields editable here (visible to hrd_payroll).
