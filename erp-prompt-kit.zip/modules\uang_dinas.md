### Field Allowance / Uang Dinas (`uang_dinas`) — OPTIONAL (field team)
- **Depends on:** mekanik_report, payroll (rates)
- **Default roles:** mekanik, freelance, owner, gm, finance_director
- **Created automatically** when a visit is `Selesai`, and as a project-level placeholder for MR SOs.
- **Amount** = days × CURRENT payroll `uangDinasRate` (live rate, not the frozen row rate) + pocket money (`uangSaku`).
- **Access (enforce in RLS)**
  - Super users (owner-like + `uang_dinas:admin`) and designated workshop leads: see/edit/pay everyone.
  - Field staff: only their OWN rows.
- **Payment** feeds the journal.
