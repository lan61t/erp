### Bank Reconciliation (`bank_recon`) — CORE
- **Depends on:** jurnal
- **Default roles:** finance, finance_director, owner, gm
- **One statement ledger per bank account** (from Brief).
- **Entries:** `Masuk` / `Keluar`.
  - Auto-posted from Journal "Tandai Lunas".
  - Manual: deposits, transfers, bank fees.
- **Opening balance** is just a normal manual `Masuk` entry (one flat list, no special schema).
- **Features:** running balance, reconcile tick, Excel export.
