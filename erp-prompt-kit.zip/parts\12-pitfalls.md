# 12. Known pitfalls (from the blueprint's bug history — design these out)

<!-- EDITOR NOTE: Add new pitfalls here after each client project. This list gets more valuable every time. -->

1. Whole-collection overwrite races lost stock and vanished POs/IRs → **row-level atomic RPCs only**.
2. Matching records by object identity after a background refresh silently dropped edits → **always match by primary key**.
3. Quotation revision families: SO → quotation lookups must resolve through the family (3 separate bugs).
4. Raw-sum stock reservation double-counted → **FIFO allocation**; reservation must come from every active SO's full need, not only requisitions.
5. Delivery never decremented stock and could ship with zero stock → decrement atomically; hard-block shortfall.
6. Dinas Luar double-counted inside Riil; half-day leave wiped the diligence allowance; negative-leave hacks → explicit override fields.
7. Case-sensitive name matching hid 90% of a sales manager's clients → use IDs/usernames, not display names.
8. Stale cached HTML after deploy → no-cache on the shell; show build id.
9. Per-part reservation recomputation froze the item list → bulk/DB computation.
10. Profile update blocked by RLS looked like success → check affected-row count, show errors.
11. Default password `username123`, client-side SHA-256, `Math.random` IDs, unescaped print HTML → never repeat.
12. Hard-coded person names in logic → use roles and configurable username lists.
13. Bank account hard-coded in invoice print → make it a setting.
14. Optimistic UI with swallowed errors diverged from server → always show failures.
15. Revenue not posted when the approval step was removed → when a policy skips a step, move its side-effects to the surviving step.
