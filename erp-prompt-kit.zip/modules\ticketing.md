### Travel Tickets (`ticketing`) — OPTIONAL
- **Depends on:** sales_order
- **Default roles:** sales_admin, owner, gm
- **Purpose:** tickets (plane / ship / train-bus) for staff going to remote sites.
- **Rules**
  - Entered by sales_admin; **no approval**.
  - Links to one or more SOs.
  - Posts to the journal as a cost.
