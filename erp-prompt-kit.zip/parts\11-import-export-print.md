# 11. Import, export and print

<!-- EDITOR NOTE: Per-module print/import details also live inside each module file. This part holds only the shared rules. -->

## Excel import
- Validate headers with accepted aliases.
- Show a preview and error rows.
- Never apply partially and silently.

## Excel export (styled)
- Letterhead, bordered header, number format, total row.
- Signature block: "City, <long date> … <name>".

## Print
- All user strings HTML-escaped.
- Letterhead, signature image, bank info and terms come from Company Settings.
- Client-facing prints hide internal fields (rule 6.10).
