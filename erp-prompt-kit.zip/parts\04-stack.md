# 4. Tech stack and architecture

<!-- EDITOR NOTE: To go back to Foresta's single-file approach, replace this whole part. Not recommended for money/stock/payroll. -->

## Why not copy the blueprint's storage
- Blueprint stored ~55 collections as whole JSON arrays in one key/value table and rewrote the whole array on every save.
- Result: lost stock increments, overwritten documents, "approved but not applied" records, 30-second freezes, permissions only in browser code.
- **Copy the behavior, not the storage model.**

## Frontend
- Vite + React 18 + TypeScript (strict), React Router, TanStack Query.
- Own small component kit: Table, Modal, Btn, Input, Select, Badge, Card, CollapsibleSection, ItemPicker, MobileCardList, DialogHost (`askConfirm`, `askPrompt`).
- CSS variables for light/dark theme.
- Virtualize any table over 200 rows.

## Backend
- Supabase: Postgres, Auth, Realtime, Storage, Row Level Security.
- Real relational tables, one row per record, line items in child tables.
- `jsonb` only for truly schema-less payloads (e.g. inspection checklists).

## Atomic server-side operations (Postgres functions / RPC) — mandatory for
- Document numbering.
- Stock increase / decrease.
- Approval transitions.
- Payment recording.
- Journal posting.
- Edit-request approval.
- Stock reservation.
- The client must never read-modify-write a whole list.

## Document numbers
- Generated server-side from a per-type counter row locked `FOR UPDATE`.
- Unique constraint on `(type, nomor)`.
- Revisions append `-R1`, `-R2`.
- Invoice numbers are never renumbered after issue (tax implications).

## Concurrency
- Optimistic UI is fine; every mutation returns the authoritative row.
- Failures are shown to the user, never only logged.
- Edits check `updated_at` / row version; conflict shows "record changed, reload".

## Auth
- Supabase Auth; username → synthetic email `username@<company>.local`.
- `profiles`: name, username, role, `active`, `custom_modules text[]`, HR/payroll fields.
- **No default passwords** (blueprint used `username123` — a defect).
- Create users with a one-time random password; force change on first login.
- No client-side hashing as a substitute for auth.

## Authorization
- Enforced in RLS policies and RPCs; mirrored in UI for UX only.
- Role/module rules must exist as SQL, not just React conditionals.

## Realtime
- Subscribe to changed tables of the visible module; debounce refetch.
- No full-store polling.

## Security baseline (all were audit findings in the blueprint)
- Escape every user string used in print/HTML.
- IDs from `crypto.randomUUID()` or DB sequences, never `Math.random()`.
- No secrets in the repo; CSP-friendly.
- Uploads (logo, signatures) size-limited and type-checked.

## Print, Excel, offline
- Printable HTML per document (letterhead, signature, bank info, terms) → `window.print()` to PDF.
- Excel import/export with a styled-xlsx library (headers, borders, number format, totals, signature block).
- Cache last-loaded read data; never cache writes.

## Testing
- Vitest for pure logic: stock allocation, totals, payroll, overtime, commission, numbering.
- Playwright smoke test of the golden path.
- SQL tests for RLS: each role can / cannot.

## Deployment
- Static frontend (GitHub Pages / Netlify / Vercel) + Supabase.
- Provide `supabase/migrations/*.sql`, seed script, `.env.example`, README with deploy steps.
- `index.html` must be served no-cache (blueprint's stale-build bug).
- Show `APP_BUILD` (date.sequence) in the footer and in error logs.
