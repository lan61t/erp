### Supplier Database (`supplier`) — CORE for goods businesses
- **Depends on:** none
- **Default roles:** purchasing, purchasing_overseas, finance_director, owner, gm
- **Fields:** name, contacts, bank, payment terms, currency.
- **Structure:** local and overseas as separate tabs (drop overseas if not needed).
- **Import:** Excel.
