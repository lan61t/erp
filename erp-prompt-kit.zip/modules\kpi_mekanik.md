### Field Staff KPI (`kpi_mekanik`) — OPTIONAL (field team)
- **Depends on:** mekanik_report
- **Default roles:** mekanik, freelance, service_manager, workshop_manager, owner, gm
- **Scorecard from reports:** jobs, on-time completion, severity mix, visits, part-recommendation conversion.
- **Features:** period filter, export.
