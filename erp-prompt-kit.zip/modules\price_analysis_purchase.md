### Purchase Price Analysis (`price_analysis_purchase`) — OPTIONAL
- **Depends on:** po_local or po_overseas
- **Default roles:** purchasing, purchasing_overseas, finance_director, owner, gm
- **Shows:** purchase-price trend per item / supplier / currency.
