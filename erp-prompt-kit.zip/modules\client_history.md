### Client History (`client_history`) — OPTIONAL
- **Depends on:** customer
- **Default roles:** sales_manager, finance_director, owner, gm
- **Read-only 360° view per client:** quotations, SOs, invoices, payments, activities.
