### Master Unit / Product Package with BOM (`master_unit`) — OPTIONAL
- **Depends on:** master_part
- **Default roles:** inventory, owner, gm
- **Fields**
  - Code, name, price.
  - `bom[] {partNumber, partName, qty}`.
  - `bomUpdatedAt` stamp, bumped on any BOM change (feeds the BOM revision warning, rule 6.9).
- **Used by:** quotations (unit lines), SO/IR BOM explosion.
- **If removed:** quotation unit lines become plain items; drop BOM explosion for unit lines and the BOM warning.
