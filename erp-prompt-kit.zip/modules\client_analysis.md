### Client Analysis (`client_analysis`) — OPTIONAL
- **Depends on:** customer, sales_order
- **Default roles:** sales_manager, finance_director, owner, gm
- **Shows:** client ranking by revenue and frequency, sector split, new vs returning, concentration.
