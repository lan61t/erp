### Audit Trail (`audit_trail`) — CORE
- **Depends on:** platform audit log (rule 6.5)
- **Default roles:** owner, gm (others optional)
- **Features**
  - Filter by module, document number, actor, date.
  - Export to Excel.
  - Shows submissions, approvals, rejections, edits, deletes, payments.
