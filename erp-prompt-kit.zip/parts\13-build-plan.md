# 13. Build plan (phases — wait for my "continue" after each)

<!-- EDITOR NOTE: The assembler lists enabled modules per group above. Phases below only mention groups; skip a phase if all its modules are disabled. -->

- **Phase 0 — Foundations (always)**
  - Repo, Vite/TS, Supabase migrations, component kit, DialogHost.
  - Auth + profiles + RLS skeleton, roles/modules model, sidebar groups, dashboard shell.
  - Company settings, user management, audit + activity log, numbering RPC.
  - Edit-request + two-gate delete engine, badge engine.
- **Phase 1 — Masters and Sales**: DATABASE group, SALES group, Sales Order.
- **Phase 2 — Procure → Stock → Ship**: requisition, POs, goods receipt, parts use, delivery, stock movement, document trail, purchase price analysis.
- **Phase 3 — Field / Workshop**: WORKSHOP and EXPENSES groups, workshop dashboard, field KPI.
- **Phase 4 — Finance**: invoice, journal, bank reconciliation, financial dashboard, financial statements, chart of accounts.
- **Phase 5 — HR and KPI**: attendance, leave, meal allowance, payroll, user analysis, commission, sales KPI.
- **Phase 6 — Hardening**
  - RLS test suite per role; load test (5k items / 20k documents).
  - Mobile pass, accessibility pass.
  - Backup/restore runbook, deploy docs.
  - Optional legacy-data migration.
- Each phase ends with: migrations applied, seeds, tests green, short demo script, updated `docs/MODULES.md`.
