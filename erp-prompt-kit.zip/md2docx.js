// Minimal Markdown -> Word converter (headings, bullets, numbered lists, pipe tables, code blocks,
// bold/italic/inline code, quotes, rules). Used by assemble.js. Requires: npm install
const fs = require("fs");
const d = require("docx");
const { Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle, LevelFormat, AlignmentType, Footer, PageNumber } = d;

const FONT = "Calibri", MONO = "Consolas", W = 9360;
const border = { style: BorderStyle.SINGLE, size: 4, color: "B8C0CC" };
const borders = { top: border, bottom: border, left: border, right: border };

function inline(text, base = {}) {
  const runs = [];
  const re = /(\*\*[^*]+\*\*|`[^`]+`|\*[^*\s][^*]*\*)/g;
  let last = 0, m;
  while ((m = re.exec(text))) {
    if (m.index > last) runs.push(new TextRun({ text: text.slice(last, m.index), ...base }));
    const t = m[0];
    if (t.startsWith("**")) runs.push(new TextRun({ text: t.slice(2, -2), bold: true, ...base }));
    else if (t.startsWith("`")) runs.push(new TextRun({ text: t.slice(1, -1), font: MONO, size: 19, shading: { type: ShadingType.CLEAR, fill: "EEF1F5" }, ...base }));
    else runs.push(new TextRun({ text: t.slice(1, -1), italics: true, ...base }));
    last = m.index + t.length;
  }
  if (last < text.length) runs.push(new TextRun({ text: text.slice(last), ...base }));
  return runs.length ? runs : [new TextRun({ text: "", ...base })];
}

function table(rows) {
  const cols = rows[0].length, cw = Math.floor(W / cols);
  const widths = Array(cols).fill(cw); widths[cols - 1] += W - cw * cols;
  return new Table({
    width: { size: W, type: WidthType.DXA }, columnWidths: widths,
    rows: rows.map((r, ri) => new TableRow({
      tableHeader: ri === 0,
      children: r.map((c, ci) => new TableCell({
        width: { size: widths[ci], type: WidthType.DXA }, borders,
        shading: ri === 0 ? { type: ShadingType.CLEAR, fill: "DCE6F2" } : undefined,
        margins: { top: 60, bottom: 60, left: 100, right: 100 },
        children: [new Paragraph({ children: inline(c, { size: 19, bold: ri === 0 ? true : undefined }) })],
      })),
    })),
  });
}

function convert(md, outPath, title = "ERP Build Prompt") {
  const lines = md.replace(/\r/g, "").split("\n");
  const children = [];
  let i = 0;
  while (i < lines.length) {
    const ln = lines[i];
    if (ln.startsWith("```")) {
      const code = []; i++;
      while (i < lines.length && !lines[i].startsWith("```")) code.push(lines[i++]);
      i++;
      code.forEach(c => children.push(new Paragraph({ spacing: { after: 0 }, shading: { type: ShadingType.CLEAR, fill: "F3F5F8" }, children: [new TextRun({ text: c === "" ? " " : c, font: MONO, size: 17 })] })));
      children.push(new Paragraph({ spacing: { after: 120 }, children: [] }));
      continue;
    }
    if (/^\|.*\|\s*$/.test(ln) && /^\|[\s:|-]+\|\s*$/.test(lines[i + 1] || "")) {
      const cells = s => s.trim().replace(/^\||\|$/g, "").split(/(?<!\\)\|/).map(x => x.trim().replace(/\\\|/g, "|"));
      const rows = [cells(ln)]; i += 2;
      while (i < lines.length && /^\|.*\|\s*$/.test(lines[i])) rows.push(cells(lines[i++]));
      const n = rows[0].length;
      children.push(table(rows.map(r => { const x = r.slice(0, n); while (x.length < n) x.push(""); return x; })));
      children.push(new Paragraph({ spacing: { after: 120 }, children: [] }));
      continue;
    }
    let m;
    if ((m = ln.match(/^(#{1,4}) (.*)/))) {
      const lvl = Math.min(m[1].length, 3);
      children.push(new Paragraph({ heading: [HeadingLevel.HEADING_1, HeadingLevel.HEADING_2, HeadingLevel.HEADING_3][lvl - 1], children: inline(m[2]) }));
    } else if (/^---+\s*$/.test(ln)) {
      children.push(new Paragraph({ spacing: { before: 60, after: 60 }, border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: "B8C0CC", space: 1 } }, children: [] }));
    } else if (ln.startsWith("> ")) {
      children.push(new Paragraph({ indent: { left: 360 }, border: { left: { style: BorderStyle.SINGLE, size: 18, color: "6B8EC2", space: 8 } }, spacing: { after: 60 }, children: inline(ln.slice(2), { italics: true, color: "444B57" }) }));
    } else if ((m = ln.match(/^(\s*)[-*] (.*)/))) {
      const lvl = Math.min(Math.floor(m[1].length / 2), 2);
      children.push(new Paragraph({ numbering: { reference: "bul", level: lvl }, spacing: { after: 40 }, children: inline(m[2]) }));
    } else if ((m = ln.match(/^\s*(\d+)\. (.*)/))) {
      children.push(new Paragraph({ numbering: { reference: "num", level: 0 }, spacing: { after: 40 }, children: inline(m[2]) }));
    } else if (ln.trim() !== "") {
      children.push(new Paragraph({ spacing: { after: 100 }, children: inline(ln) }));
    }
    i++;
  }
  const lv = fmt => [0, 1, 2].map(l => ({ level: l, format: fmt, text: fmt === LevelFormat.BULLET ? ["•", "–", "·"][l] : `%${l + 1}.`, alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 540 + l * 360, hanging: 270 } } } }));
  const doc = new Document({
    creator: "ERP Prompt Kit", title,
    styles: {
      default: { document: { run: { font: FONT, size: 21 } } },
      paragraphStyles: [
        { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 32, bold: true, font: FONT, color: "1F3A5F" }, paragraph: { spacing: { before: 360, after: 140 }, outlineLevel: 0 } },
        { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 26, bold: true, font: FONT, color: "2F5597" }, paragraph: { spacing: { before: 240, after: 100 }, outlineLevel: 1 } },
        { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true, run: { size: 23, bold: true, font: FONT, color: "3B6AA0" }, paragraph: { spacing: { before: 180, after: 80 }, outlineLevel: 2 } },
      ],
    },
    numbering: { config: [{ reference: "bul", levels: lv(LevelFormat.BULLET) }, { reference: "num", levels: lv(LevelFormat.DECIMAL) }] },
    sections: [{
      properties: { page: { size: { width: 12240, height: 15840 }, margin: { top: 1260, bottom: 1260, left: 1440, right: 1440 } } },
      footers: { default: new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: title + " — page ", size: 17, color: "777777" }), new TextRun({ children: [PageNumber.CURRENT], size: 17, color: "777777" })] })] }) },
      children,
    }],
  });
  return Packer.toBuffer(doc).then(b => fs.writeFileSync(outPath, b));
}
module.exports = { convert };
