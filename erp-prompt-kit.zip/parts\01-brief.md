# 1. Project Brief (CLIENT-SPECIFIC — edit this file for every new client)

<!-- EDITOR NOTE: This is the ONLY file you must rewrite per client. Anything left as {{...}} makes the AI ask you. Delete lines you don't care about. -->

## Company
- Name: {{COMPANY_NAME}}
- Legal form: {{PT / CV / Ltd / Inc}}
- Address: {{ADDRESS}}
- Phone / email: {{PHONE}} / {{EMAIL}}
- Tax ID: {{NPWP / VAT / EIN}}
- Logo: {{will upload later}}
- Bank accounts (used on invoice print + bank reconciliation): {{BANK 1}}, {{BANK 2}}

## Industry
- What the company sells / does and how it earns money: {{ONE PARAGRAPH}}
- Sells physical goods (needs inventory)? {{yes/no}}
- Sells services or projects? {{yes/no}}
- Has a workshop or field team? {{yes/no}}
- Manufactures products? {{yes/no}} (if yes, add Production flow — see Domain Mapping)
- Buys from overseas suppliers (multi-currency)? {{yes/no}}

## Localization
- Country: {{ID}} (drives tax, payroll law, overtime rules, date format)
- UI language: {{id | en}} (blueprint labels are Indonesian; keep status strings exactly if `id`)
- Base currency: {{IDR}}
- VAT rate: {{11}}%
- Fiscal year starts in month: {{1}}
- Timezone: {{Asia/Jakarta}}

## Document numbering
- Pattern: `{TYPE}-{SEQ3}-{ORGCODE}-{ROMAN_MONTH}-{YEAR}` (example: `SO-001-FRT-VII-2026`)
- Org code (3 letters): {{ABC}}
- Sequence never resets; only the month/year suffix changes.

## Roles to enable
- Keep / rename / remove from the list in Section 5.
- Roles wanted: {{owner, gm, finance_director, sales_manager, ...}}
- Extra roles needed: {{...}}

## Modules to enable
- Edit `modules.config.json` (set `"enabled": false` to remove a module), then re-run `node assemble.js`.
- Extra modules not in the blueprint: {{...}}

## Term overrides (blueprint word → client word)
- Mekanik → {{Technician / Field Engineer}}
- Unit → {{Product / Machine / Package}}
- Part → {{Item / SKU / Material}}
- Mill → {{Site / Branch / Project Location}}
- Client categories: {{SECTOR 1, SECTOR 2, ...}}

## Policies
- Approver roles ("owner-like"): {{owner, gm, finance_director}}
- Invoice needs approval? {{no — blueprint auto-approves}}
- Second approval on delete? {{yes}}
- Sales commission: new customer {{1.2}}% / returning {{0.8}}%
- Sales KPI targets: revenue/month {{...}}, new contacts {{15}}, follow-ups {{30}}, quotations {{10}}

## Data and deployment
- Existing data to migrate: {{none | Excel | other system}}
- Deploy target: {{GitHub Pages | Netlify | Vercel | VPS}}
- Backend: Supabase (Postgres + Auth + Row Level Security)
