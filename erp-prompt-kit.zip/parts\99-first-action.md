# 15. First action

- Do **not** write code yet.
- Start with protocol step 1: read the Brief; if anything is `{{...}}` or ASK, send ONE batched question list (with defaults).
- Then step 2 (domain mapping table) and step 3 (plan).
- Wait for my approval before building.
