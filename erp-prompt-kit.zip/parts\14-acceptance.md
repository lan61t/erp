# 14. Acceptance checks

<!-- EDITOR NOTE: Skip any check whose modules are disabled. Add client-specific checks at the bottom. -->

1. **Golden path**
   - Sales manager drafts quotation → submits → GM approves.
   - Sales admin creates SO → inventory creates requisition for shortfall → purchasing creates PO → GM approves.
   - Storage receives at head office (status `Diterima HO - Menunggu Konfirmasi Workshop`, internal DO created, **stock unchanged**).
   - Logistic confirms at workshop (**stock +qty**) → creates delivery order (**stock −qty**; blocked when insufficient).
   - Finance creates invoice from a termin (DP then final) → records payments.
   - Journal, bank reconciliation and ledger entries exist and balance.
   - Document Trail shows the whole chain.
2. **Concurrency**: two browsers approve different edit-requests / receive goods on the same item at once → no lost update; both audit entries present.
3. **FIFO**: 3 SOs compete for 2 units of stock → total shortfall = demand − stock; only the queue losers get a requisition.
4. **Revision family**: revising an approved quotation that already has an SO does not resurrect it in follow-up lists.
5. **Permissions (automated per role)**
   - Every role opens only its modules.
   - Payroll / User Analysis locks hold even with custom modules.
   - Field staff see only their own allowance rows.
   - Sales manager sees only assigned clients.
   - All verified at the **database** level.
6. **Delete**: non-owner delete creates a pending request; approval applies it; owner deletes directly; linked rows cleaned.
7. **Client-facing prints** (Quotation, SO, Invoice, DO) show no internal description and no sales-discount kickback.
8. **Unit tests** for totals, commission, overtime, absence, payroll match worked examples.
9. **Journal engine**: unbalanced → no post; missing mapping → no post and no exception; re-fired event replaces, never duplicates.
10. **Mobile (375 px)**: every list renders as cards, every form usable, no horizontal scroll.
11. **Security**: no default passwords; escaped prints; RLS on every table; no secrets in repo.
12. **Docs**: README with deploy steps, `.env.example`, `docs/*` complete.
