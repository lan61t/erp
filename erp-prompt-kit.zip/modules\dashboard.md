### Dashboard (`dashboard`) — CORE
- **Depends on:** none
- **Default roles:** all
- **Purpose:** landing page per user.
- **Shows**
  - Greeting + role badge.
  - "Modules you can access" with approval badges.
  - Due-date reminders: invoices coming due/overdue (receivables) and POs (payables) — finance-type roles only.
  - Recent activity.
