### Workshop Dashboard (`workshop_dashboard`) — OPTIONAL (field team)
- **Depends on:** mekanik_report
- **Default roles:** workshop_manager, owner, gm
- **Shows**
  - Field reports awaiting workshop-manager approval.
  - Jobs in progress.
  - Maintenance due.
- **Badge:** reports awaiting approval.
