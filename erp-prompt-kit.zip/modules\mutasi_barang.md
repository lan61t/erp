### Stock Movement Ledger (`mutasi_barang`) — CORE for goods businesses
- **Depends on:** goods_receipt, delivery_order
- **Default roles:** inventory, purchasing, storage, logistic, workshop_manager, owner, gm
- **Read-only and fully derived** — never entered manually.
- **In (Masuk):** goods receipts.
- **Out (Keluar):** delivery orders, parts-use returns, adjustments.
- **Searchable by:** part number, name, description, customer name, customer PO, supplier PO.
