# 2. Product summary

- One web ERP for one company, ~15–20 staff roles.
- Covers: order-to-cash, procure-to-pay, inventory, field/workshop, finance/accounting, HR/payroll, KPI, administration.
- Must-keep characteristics:
  - **Document-driven**: every event is a numbered document linked to its predecessor (quotation → sales order → requisition → purchase order → goods receipt → delivery → invoice → payment).
  - **Approval-driven**: owner/GM approval on money-affecting documents, with rejection reason and history.
  - **Role-driven**: each role sees only its modules and its permitted rows; sensitive modules are hard-locked.
  - **Audit-driven**: every create/edit/approve/reject/delete is logged (actor, role, time, detail).
  - **Accounting-integrated**: business events auto-post balanced journal entries.
  - **Mobile-usable**: every screen works at 375 px.
