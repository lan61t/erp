### Financial Dashboard (`financial_dashboard`) — CORE
- **Depends on:** invoice, po_local or po_overseas
- **Default roles:** owner, gm, finance, finance_director
- **Shows**
  - Receivables aging and payables aging.
  - Overdue invoices (excluding those flagged `longOverdue`) and overdue POs.
  - Cash in/out summary and per-bank balance.
- **Badge:** count of overdue invoices + overdue POs.
