# 10. Seed data and reference lists

## Chart of accounts (general ledger) seed
- Numeric, grouped by type; **editable** after seeding.
- 1xxx Assets: 1101 Petty Cash, 1102 Main Cash, 1111 Bank 1, 1112 Bank 2, 1113 Other Bank, 1120 Accounts Receivable, 1121 Bad-debt Allowance, 1130 Employee Receivable, 1140 Inventory, 1141 Goods in Transit, 1150 Input VAT, 1160 Purchase Advance, 1170 Prepaid Expenses, fixed assets + accumulated depreciation.
- 2xxx Liabilities: 2110 Payable Local, 2111 Payable Overseas, 2120 Sales Advance, 2130 Salary Payable, 2131 Commission Payable, 2132 Other Expense Payable, 2140 Output VAT, 2141 Income Tax 21, 2142 Income Tax 23, 2143 Final Tax, 2150 Short-term Bank Debt, 2160 Accrued Expenses.
- 3xxx Equity.
- 4xxx Revenue: product revenue, service revenue, parts revenue.
- 5xxx Expenses: 5210 Base Salary, 5211 Overtime, allowances, social insurance, commission, depreciation per asset category, operating expenses.
- Rename inventory/revenue accounts to the client's industry.

## Other reference lists
- Client categories (from Brief).
- Part sub-categories (seed: ATK, Consumable, Electrical, Material, Hydraulic).
- Inspection checklists as data-driven templates.
- Severity / status / condition option lists (see field-service module).
- Weekdays (Senin–Minggu) and Indonesian month names.

## Users
- Seed only an `owner` admin with a random one-time password printed once at setup.
- No demo accounts in production seeds.
- A separate `seed:demo` script creates one user per role + realistic sample customers, items, documents (for demos and Playwright).

## Setting defaults
- Company info and bank info from Brief.
- Due-soon threshold 3 days.
- Maintenance interval 3 months; "Segera" = 14 days.
- Leave quota 12 days/year.
- Audit retention 180 days.
