# ERP Prompt Kit (baseline)

Modular prompt for building a customized ERP, derived from FORESTA ERP. Edit small files, switch modules on/off, then assemble one prompt.

## Easiest way: the Builder app
- Double-click **`ERP-Prompt-Builder.html`** (opens in any browser, works offline, no install).
- Tabs: 1 Brief form → 2 tick/untick modules → 3 edit any section → 4 Copy / download the final prompt.
- Your choices are saved in the browser. If you change any `.md` file or `modules.config.json`, run `node build-html.js` to refresh the app.

## Per-client workflow (file-based alternative)
1. Copy this whole folder → `erp-prompt-kit-<clientname>/`.
2. Edit **`parts/01-brief.md`** — the only file you must rewrite for each client.
3. Open **`modules.config.json`** and set `"enabled": false` on modules the client doesn't need.
4. Run:
   ```bash
   npm install        # first time only (needed for the Word file)
   node assemble.js   # writes dist/PROMPT.md and dist/PROMPT.docx
   ```
   - The script prints WARNINGs if you disabled a module that another enabled module requires.
5. Paste `dist/PROMPT.md` (or the text of `PROMPT.docx`) as the first message in a new Claude Code session.
6. The AI asks any remaining questions, shows a domain mapping and a plan, then builds phase by phase.

## Folder map
| Path | What it is | Edit when… |
|---|---|---|
| `parts/01-brief.md` | Client details, industry, roles, policies | **every client** |
| `modules.config.json` | Module on/off switches + dependencies | **every client** |
| `modules/<id>.md` | One short bullet spec per module (46 files) | a module's behavior changes |
| `parts/00-protocol.md` | How the AI should work (ask → map → plan → build) | rarely |
| `parts/03-domain-mapping.md` | Blueprint concept → industry equivalent | you serve a new industry |
| `parts/04-stack.md` | Tech stack and architecture | stack preference changes |
| `parts/05-roles-access.md` | Role mechanics and role list | roles differ |
| `parts/06-global-rules.md` | Approvals, delete, audit, formats, UX | a global rule changes |
| `parts/09-algorithms.md` | Stock/FIFO, numbering, totals, journal, overtime | formulas change |
| `parts/10-seed-data.md` | Chart of accounts and lists | local accounting differs |
| `parts/12-pitfalls.md` | Bugs to design out | **add lessons after each project** |
| `parts/13-build-plan.md`, `14-acceptance.md` | Phases and tests | process changes |

- Section 7 (sidebar + enabled/disabled list) and Section 8 (module specs) are **generated** — never edit them in `dist/`.
- `<!-- EDITOR NOTE: … -->` comments in any file are stripped from the output; use them for private reminders.

## Adding a new module
1. Create `modules/<new_id>.md` using the same bullet layout (Depends on / Default roles / Fields / Rules).
2. Add an entry in `modules.config.json` (group, label, `requires`).

## Notes
- `dist/PROMPT.md` is the file to use; the Word file is the same content for reading/sharing.
- The earlier single-file version (`../ERP_REBUILD_PROMPT.md`) is superseded by this kit.
