### Operation Cost (`workshop_ops`) — OPTIONAL
- **Depends on:** master_coa
- **Default roles:** sales_admin, owner, gm
- **Purpose:** operational expenses entered by sales_admin, categorized from the flat expense-tag list (Master COA).
- **Export:** Excel.
