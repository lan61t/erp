# 5. Roles and access model

<!-- EDITOR NOTE: Each module file lists its own "Default roles". Deleting a module removes its role entries automatically. Edit the role list below per client. -->

## Mechanics (keep exactly)
- `profiles.role` selects the default module list.
- `profiles.custom_modules` (optional array) overrides the role default per user.
- **Admin grant**: a pseudo-entry `"<module_id>:admin"` in `custom_modules` gives full/admin behavior inside that module without changing the role.
- **Modules forced on for every user** (if enabled): leave request, own meal allowance, item catalog lookup, document trail.
- **Hard locks** (custom modules cannot unlock):
  - Payroll → owner, gm, hrd_payroll only.
  - User Analysis → owner, gm, hrd, hrd_payroll only.
  - Field Allowance → super users + designated leads + admin grant; every field staff sees only OWN rows (enforce in RLS).
- **Owner-like** = owner, gm, finance_director (rename in Brief).
  - Approve documents, see everything.
  - Skip the second delete gate (they are the approver).
- Designated GM account is normalized to role `gm` at login (generalize; never hardcode a person).
- **Client visibility**
  - Sales managers see only customers assigned to them (`salesManagerUsernames[]`).
  - All other roles and owner-like see all customers.
  - Sales can request access to a client (edit-request flow).
- **Sidebar badges**: each module shows the count of items awaiting THIS user's action (e.g. GM sees quotations "Menunggu Approval GM"). Same counts on the Dashboard.

## Role list (starting point)
- `owner` — all modules, approver.
- `gm` — all modules, approver.
- `finance_director` — finance + analysis, approver.
- `sales_manager` — quotations, own clients, KPI.
- `sales_admin` — sales orders, tickets, delivery.
- `service_manager` — service quotations, field reports.
- `workshop_manager` — workshop approvals, maintenance.
- `inventory` — requisitions, item catalog.
- `purchasing` — local purchase orders.
- `purchasing_overseas` — overseas purchase orders.
- `storage` — goods receipt.
- `logistic` — receipt confirmation, parts use, delivery.
- `finance` — invoices, journal, bank.
- `hrd` — attendance, user analysis.
- `hrd_payroll` — payroll + attendance.
- `mekanik` — field reports, own allowance.
- `freelance` — same as mekanik, separate for reporting.
- `driver` — empty list + forced modules (configure later).

## User admin screen (Manajemen User) must support
- Create user, set role, set custom modules (checkbox matrix incl. `:admin`), activate/deactivate, reset password, edit HR/payroll fields, rename cascade.
- Deactivated users disappear from every picker.
