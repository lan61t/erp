### Price Analysis — Sales (`price_analysis`) — OPTIONAL
- **Depends on:** quotation_unit or sales_order
- **Default roles:** sales_manager, sales_admin, finance_director, owner, gm
- **Shows:** selling-price trend and variance per item / client / period (charts + table + export).
