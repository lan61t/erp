# 3. Domain mapping (adapting the blueprint to any industry)

<!-- EDITOR NOTE: Add a row for any new industry you serve often. -->

| Blueprint concept | Generic meaning | Adapt by |
|---|---|---|
| Master Part | Stockable item catalog | Rename (Item/Product/Material). Keep stock, BOM, categories. |
| Master Unit (BOM) | Sellable package/assembly made of items | Rename or drop. |
| Master Mill | Customer site/location database | Rename (Site/Branch/Project). |
| Database Client | Customers with sector, group, owner, payment rating | Keep. Replace category list. |
| Database Supplier | Local vs overseas suppliers | Keep. Drop overseas if not needed. |
| Unit Quotation / Parts & Service Quotation | Big-ticket vs repeat/service quote | Keep both, or merge into one with a `type` field. |
| Sales Order routing IR / MR / BOTH | Route to procurement, to field job, or both | Keep; rename MR; hide MR if no field work. |
| Mekanik Report suite | Field service / job documentation | Rename; drop if no field team. |
| Maintenance Schedule | Recurring service per sold asset | Keep only if after-sales service exists. |
| Uang Dinas / Ticketing / Operation Cost | Field allowance, travel, opex | Keep as Field Allowance / Travel / Opex. |
| Manufacturing (NOT in blueprint) | Production | Add Work Order, material issue (reuse Parts Use), finished-goods receipt (reuse Goods Receipt), BOM explosion (reuse), WIP/COGS posts. |
| Services-only company | No stock | Disable Master Part, Goods Receipt, Delivery Order, Mutasi; invoice directly from SO/project. |

- Finance, HR, KPI/Analytics, Trail and Settings are industry-neutral: keep them, only localize.
