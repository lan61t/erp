### Document Trail (`document_trail`) — CORE (visible to every user)
- **Depends on:** sales_order (plus whichever of item_requisition, po_*, goods_receipt, delivery_order, invoice are enabled)
- **Purpose:** let every department see where a job stands without opening each module.
- **Shows**
  - Chain SO → IR → PO → GR → DO (→ Invoice).
  - For each stage: document, status, quantity fulfilled, what is blocking.
- **Search by:** SO, PO, customer.
