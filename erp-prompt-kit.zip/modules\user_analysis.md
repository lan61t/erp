### User Analysis (`user_analysis`) — OPTIONAL, **HARD-LOCKED** to owner, gm, hrd, hrd_payroll
- **Depends on:** platform activity log (rule 6.6)
- **Shows:** per-person login and module-usage analytics: adoption heat-map, last login, modules visited, inactivity.
