#!/usr/bin/env node
// Assembles the final ERP build prompt from parts/ + the enabled modules/ listed in modules.config.json.
// Usage:  node assemble.js            -> dist/PROMPT.md  and  dist/PROMPT.docx
//         node assemble.js --md-only  -> dist/PROMPT.md only (no npm install needed)
const fs = require("fs");
const path = require("path");

const ROOT = __dirname;
const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, "modules.config.json"), "utf8"));
const mdOnly = process.argv.includes("--md-only");

const stripNotes = s => s.replace(/<!--[\s\S]*?-->\s*\n?/g, "").replace(/\n{3,}/g, "\n\n").trim() + "\n";
const read = p => stripNotes(fs.readFileSync(p, "utf8"));

const enabled = new Set(cfg.modules.filter(m => m.enabled).map(m => m.id));
const warnings = [];

// 1. dependency check (each inner list = any-of)
for (const m of cfg.modules.filter(m => m.enabled)) {
  for (const anyOf of m.requires || []) {
    if (!anyOf.some(id => enabled.has(id))) warnings.push(`"${m.id}" is enabled but needs one of: ${anyOf.join(" | ")}`);
  }
}
// 2. missing module files
for (const m of cfg.modules.filter(m => m.enabled)) {
  if (!fs.existsSync(path.join(ROOT, "modules", m.id + ".md"))) warnings.push(`missing file modules/${m.id}.md`);
}

// 3. generated sections
const generated = [];
generated.push("# 7. Sidebar structure and enabled modules\n");
generated.push("- Standalone top items (if enabled): " + cfg.modules.filter(m => m.group === "dashboards" && m.enabled).map(m => "`" + m.id + "`").join(", ") + ".");
generated.push("- Collapsible groups, in this order (any enabled module not listed here must still appear as a standalone item):");
for (const g of cfg.groups.filter(g => !g.standalone)) {
  const ids = cfg.modules.filter(m => m.group === g.key && m.enabled).map(m => "`" + m.id + "`");
  if (ids.length) generated.push(`  - **${g.label}**: ${ids.join(", ")}`);
}
const off = cfg.modules.filter(m => !m.enabled);
generated.push("");
generated.push("## Modules NOT in scope for this client");
generated.push(off.length ? "- Do not build, and remove every reference to, these modules: " + off.map(m => `\`${m.id}\``).join(", ") + "." : "- None. Build every module in Section 8.");
generated.push("- Where another module mentions a disabled module (badges, side effects, auto-posting, pickers), skip that part silently.");
generated.push("");

generated.push("# 8. Module specifications\n");
generated.push("Notation: CORE = keep in every industry; OPTIONAL = only because it is listed here. Status strings are Indonesian UI vocabulary and are kept exactly.\n");
for (const g of cfg.groups) {
  const mods = cfg.modules.filter(m => m.group === g.key && m.enabled);
  if (!mods.length) continue;
  generated.push(`## ${g.label}\n`);
  for (const m of mods) {
    const f = path.join(ROOT, "modules", m.id + ".md");
    if (fs.existsSync(f)) generated.push(read(f));
  }
}

// 4. stitch parts, inserting generated block before part 09
const parts = fs.readdirSync(path.join(ROOT, "parts")).filter(f => f.endsWith(".md")).sort();
const out = [];
let inserted = false;
for (const f of parts) {
  const n = parseInt(f, 10);
  if (!inserted && n >= 9 && n !== 99) { out.push(generated.join("\n")); inserted = true; }
  out.push(read(path.join(ROOT, "parts", f)));
}
if (!inserted) out.push(generated.join("\n"));
const md = out.join("\n") + "\n";

fs.mkdirSync(path.join(ROOT, "dist"), { recursive: true });
fs.writeFileSync(path.join(ROOT, "dist", "PROMPT.md"), md);
console.log(`dist/PROMPT.md written  (${enabled.size} modules enabled, ${off.length} disabled, ${md.split("\n").length} lines)`);
warnings.forEach(w => console.warn("WARNING: " + w));

if (!mdOnly) {
  try {
    require("./md2docx").convert(md, path.join(ROOT, "dist", "PROMPT.docx"), "ERP Build Prompt")
      .then(() => console.log("dist/PROMPT.docx written"));
  } catch (e) {
    console.warn("Word file skipped (" + e.message.split("\n")[0] + "). Run `npm install` once, then re-run.");
  }
}
