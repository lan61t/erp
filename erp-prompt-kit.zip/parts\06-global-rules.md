# 6. Global behaviors (apply to every module)

<!-- EDITOR NOTE: Each rule is independent. Delete a bullet to drop the rule. -->

## 6.1 Approval flow
- Generic: `Draft → Menunggu Approval GM → Disetujui GM | Ditolak GM (+ reason)`.
- Approver records `approvedBy`, `approvedDate`.
- Approver role is a per-module setting (workshop manager, service manager, HRD are alternatives).

## 6.2 Edit requests (maker–checker) for master data
- Non-owner-like users cannot directly Add/Edit/Delete protected master data.
- They submit `edit_request {module, action: Tambah|Edit|Hapus, targetId, targetLabel, payload, requestedBy, status}`.
- Approver sees the diff; approval applies the change atomically (RPC) and logs it.
- Pending requests are never pruned.

## 6.3 Universal two-gate delete
- Gate 1: confirm dialog ("Yakin untuk hapus item ini?").
- Gate 2: for non-owner-like users the delete becomes a pending `Hapus` request, applied only on approval.
- Owner-like users skip gate 2.
- Deleting a document cleans linked rows via RPC (e.g. deleting a leave form removes its attendance entries).
- Prefer soft delete (`deleted_at`) for financial documents.

## 6.4 Rename cascade
- Store `user_id` foreign keys; names come by join, so a rename is automatic.
- Keep `*_name_snapshot` only on printed/legal documents, with a cascade tool for snapshots.

## 6.5 Audit log
- `audit_log(id, ts, module, doc_nomor, action, detail, actor_name, actor_role)`, written by DB triggers/RPCs.
- Actions: Ajukan Tambah/Edit/Hapus, Approve, Reject, Edit (Superuser), Simpan Draft, payments, etc.
- Retention 180 days (configurable); never prune pending items.

## 6.6 User activity log
- Login + module-navigation events per user, same retention.

## 6.7 Revisions and quotation families
- A revision gets a new number `<base>-R<n>` and `revisiDari` = base.
- One shared helper answers "does this quotation (any revision) already have an SO":
  - Forward lookups (quotation → SO) resolve through the whole revision family.
  - Reverse lookups (SO → source quotation) are exact match.
- (Blueprint had this bug 3 times before consolidating.)

## 6.8 Downstream flagging on superuser edit
- When an owner-like user edits an approved quotation that already spawned an SO, flag every downstream SO/IR/PO for manual review.
- Auto-append a note to the SO only if the superuser typed one AND the SO is not locked (no shipment, no supplier PO, no paid invoice).
- Never silently change downstream qty/price.

## 6.9 BOM revision warning
- Documents snapshot `{unitCode: bomUpdatedAt}` at creation.
- Show a non-blocking "BOM revised" badge if the live stamp differs.
- Never auto-change documents.

## 6.10 Client-facing documents
- Never show the internal item description on Quotation, Sales Order, Invoice, Delivery Order (screen and print).
- Never print the internal "Sales Discount" kickback.

## 6.11 Formats
- Dates stored ISO `YYYY-MM-DD`; tables show `DD-MON-YY` (e.g. `05-OCT-26`); report signature blocks show long form (`12 Agustus 2026`).
- Money as `numeric(18,2)` or integer minor units; thousands separators; foreign currency shown `CUR amount`.

## 6.12 Payment terms
- `COD` or `TEMPO` (shown on POs as "CREDIT").
- TEMPO due date = a date OR N days from today.
- Due status: `COD | Belum Jatuh Tempo | Jatuh Tempo Segera (≤3 days) | Terlambat`.

## 6.13 Uploads
- Logo and per-user signature image (draw-on-canvas), used on prints.

## 6.14 UX
- Light/dark theme toggle persisted per browser.
- Sidebar group collapse state persisted per browser.
- Mobile: tables become card lists, grids collapse to 1 column, inputs ≥16 px, buttons ≥40 px.
- Promise-based `askConfirm` / `askPrompt` via DialogHost (no raw browser alert/confirm for awaited flows).
- Every list and form has empty, loading and error states; never fail silently.
