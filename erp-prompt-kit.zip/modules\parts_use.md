### Parts Use / Material Release (`parts_use`) — OPTIONAL (field team or production)
- **Depends on:** sales_order, master_part, goods_receipt
- **Default roles:** logistic, mekanik, freelance, workshop_manager, owner, gm
- **Purpose:** release items from an SO to a mechanic/job.
- **Fields:** `qtyReleased` per item.
- **Rules**
  - **Release does NOT change stock** — it only converts a reservation into a release (reduces reserved qty).
  - **Return flow:** `submitReturnRequest` → `Menunggu Konfirmasi Return` → confirmed → stock increases.
  - Supports non-SO release and edit release.
