### Master Mill / Customer Sites (`master_mill`) — OPTIONAL (field team)
- **Depends on:** none
- **Default roles:** service_manager, mekanik, freelance, workshop_manager
- **Fields:** site name, company, address, province, regency.
- **Used by:** field reports, maintenance schedule (picker).
- **Rule:** plain row-level writes (blueprint needed compare-and-swap; not needed here).
