### Meal Allowance (`uang_makan`) — OPTIONAL (visible to every user)
- **Depends on:** attendance, payroll (rates)
- **Default roles:** all (forced on); owner/gm/hrd_payroll see everyone
- **Formula:** monthly meal allowance = Σ present days × daily rate (+ 0.5× for half-days).
- **Read-only report** — numbers are owned by Attendance (days) and User Management (rate).
