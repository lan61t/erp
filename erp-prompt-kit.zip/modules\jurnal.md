### Cash Journal (`jurnal`) — CORE
- **Depends on:** invoice, po_local, payroll (sources; each optional)
- **Default roles:** finance, finance_director, owner, gm
- **Entry types:** `Pengeluaran` (outgoing) and `Pemasukan` (incoming).
- **Outgoing arrives automatically from:** approved POs, payroll run, field allowance, travel tickets, operation cost — plus manual entries.
- **Incoming arrives from:** invoice payments.
- **Approve = "Tandai Lunas"** via bank 1 / bank 2 / cash.
  - For banks, writes a matching entry into Bank Reconciliation with `sourceModule/sourceId` (the only place that writes auto bank entries).
- **Rules:** edit rules for already-paid entries.
