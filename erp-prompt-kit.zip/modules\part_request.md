### New Part Request (`part_request`) — OPTIONAL, **OFF by default** (deactivated in blueprint 2026-07-13)
- **Depends on:** master_part, mekanik_report
- **Default roles:** mekanik (create), service_manager (review), owner/gm (approve)
- **Flow:** field staff request → service manager review (`Menunggu Review Asil`) → GM approval (`Menunggu Approval GM`) → enters Master Part (`Disetujui GM - Masuk Master Part`).
- **Build note:** implement behind a feature flag; ship disabled.
