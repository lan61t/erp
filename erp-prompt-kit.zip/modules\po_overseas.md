### Purchase Order — Overseas (`po_overseas`) — OPTIONAL
- **Depends on:** po_local (shared component), supplier
- **Default roles:** purchasing_overseas, owner, gm
- **Differences from local PO**
  - Currency + `kursReferensi` (reference exchange rate).
  - Import-cost record.
  - Payable posts to the overseas-payable account.
- **Everything else:** same statuses, rules, audit and badge as Local PO.
