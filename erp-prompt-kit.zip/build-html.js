// Builds ERP-Prompt-Builder.html: one self-contained file (double-click to open) that embeds
// every part, every module and the config. Re-run after editing any .md file or the config:  node build-html.js
const fs = require("fs"), path = require("path");
const R = __dirname;
const parts = {}, modules = {};
fs.readdirSync(path.join(R, "parts")).filter(f => f.endsWith(".md")).forEach(f => parts[f.replace(/\.md$/, "")] = fs.readFileSync(path.join(R, "parts", f), "utf8").replace(/\r/g, ""));
fs.readdirSync(path.join(R, "modules")).filter(f => f.endsWith(".md")).forEach(f => modules[f.replace(/\.md$/, "")] = fs.readFileSync(path.join(R, "modules", f), "utf8").replace(/\r/g, ""));
const config = JSON.parse(fs.readFileSync(path.join(R, "modules.config.json"), "utf8"));
const data = JSON.stringify({ parts, modules, config }).replace(/</g, "\\u003c");
const html = fs.readFileSync(path.join(R, "builder.template.html"), "utf8").replace("/*DATA*/", () => data);
fs.writeFileSync(path.join(R, "ERP-Prompt-Builder.html"), html);
console.log("ERP-Prompt-Builder.html written (" + Math.round(html.length / 1024) + " KB)");
