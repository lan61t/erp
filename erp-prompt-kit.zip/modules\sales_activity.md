### Sales Activity (`sales_activity`) — OPTIONAL
- **Depends on:** customer
- **Default roles:** sales_manager, owner, gm
- **Fields:** date, activity type (visit/call/quotation/…), customer, notes, `biaya[]` operational costs, `totalBiaya`, salesperson.
- **Rules**
  - Entries are auto-created (flag `auto:true`) when a quotation or new client is created.
  - Feeds Sales KPI.
