### Parts & Service Quotation (`quotation_ps`) — OPTIONAL (can merge into Unit Quotation)
- **Depends on:** customer, quotation_unit (shared engine)
- **Default roles:** service_manager (create), owner/gm (approve)
- **Same engine as Unit Quotation**, plus:
  - Can pull mechanic **Part Recommendations** from field reports (status `Ditarik ke Quotation`).
  - Approver label may be Service Manager first, then GM.
  - Inbox of pending part recommendations (`Menunggu`) with a badge.
- **Cross-module:** Maintenance Schedule's "Buat SQ" button opens this form pre-filled with the client.
- **If merged:** keep one quotation module with a `type` field.
