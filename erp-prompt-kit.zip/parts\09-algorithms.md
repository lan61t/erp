# 9. Core algorithms

<!-- EDITOR NOTE: If you remove inventory modules, delete 9.1. If you remove payroll/attendance, delete 9.6. -->

Implement as unit-tested pure functions, plus SQL where the operation must be atomic.

## 9.1 Stock, reservation and shortfall (FIFO allocation)
- Stock (`stok`) rises on: final goods receipt, confirmed parts-use return, approved stock revision.
- Stock falls on: delivery order.
- These do NOT change stock: requisition creation, PO creation, PO receipt at head office, parts-use release.
- **Explosion**: `explodeSOItems(so)` → `{partNumber: qtyNeeded}`.
  - Unit lines → every BOM component × qty.
  - A part with its own `bom` explodes recursively (cycle guard with a `seen` set).
  - Lines with category `Service` are skipped.
  - Merge duplicates.
- **FIFO allocation** per part:
  - Take every SO with status `Aktif`.
  - `need = explodedNeed − qtyReleasedViaPartsUse`.
  - Sort by SO date, then number.
  - Hand out physical stock in that order → `{soNomor: {allocated, shortfall}}`.
  - Guarantees Σshortfall = max(0, Σneed − stock).
- `reservedQtyFor(part, excludeSo)` = Σallocated of all OTHER SOs. Available = stock − reserved.
- Requisition shortfall = that SO's `shortfall`.
- **Bulk variant**: compute all parts in one pass (explode each active SO once) — in SQL (view/function), cached. Per-part recomputation froze the blueprint for 30+ s at ~3,000 parts.

## 9.2 Document numbering
- `TYPE-SEQ3-ORG-ROMANMONTH-YEAR[-R#]`.
- SEQ = (highest sequence ever used for this TYPE, across all months/years) + 1. Never resets.
- Type codes: `UQ` unit quotation, `SQ` parts/service quotation, `SO`, `IR`, `PL` PO local, `PO` PO overseas, `GR`, `DO`, `INV` (never migrated), `CT` leave, `IDO` internal DO. Confirm the full list with the Brief.
- Server-side counter with locked row; unique `(type, nomor)`.

## 9.3 Totals
- `subtotal = Σ qty × price`.
- Client discount in % or amount.
- `taxBase = subtotal − discount`; `tax = taxBase × pct/100`; `total = taxBase + tax`.
- PO: add Σ additional costs; VAT only on items subtotal.
- SO pro-rates quotation discount/tax by `selectedSubtotal / quotationSubtotal`.
- Termin amount = percent × SO pre-tax, or fixed amount; the invoice then applies its own discount, then VAT.

## 9.4 Payment status and aging
- `terbayar` accumulates; `Lunas` when `terbayar + withholding + adminFee ≥ total`.
- Due status per 6.12.
- Client punctuality rating: share of settled TEMPO invoices paid on/before due date → `Sangat Baik ≥90 / Baik ≥70 / Cukup ≥50 / Kurang <50 / Belum Ada Data`, plus count of currently overdue invoices.
- PO `statusBayar` works the same way.

## 9.5 Journal auto-post contract
- Pure function `buildLines(event, mapping) → lines[] | null`.
- Rules:
  - Drop zero lines; need ≥2 non-zero lines.
  - Every account code must exist.
  - If |Σdebit − Σcredit| > 1 → post nothing.
  - Upsert by `(sourceType, sourceId)` so a re-fired event replaces, never duplicates.
  - Never throw or block the business action.
- Unit-test balance and idempotency.

## 9.6 Overtime (Indonesia, PP 35/2021 Art. 31–32) — localization dependent
- Hourly rate = monthly wage / 173.
- Working day: hour 1 = 1.5×, later hours = 2×.
- Rest day / holiday, 6-day week: hours 1–7 = 2×, hour 8 = 3×, hours 9–11 = 4×.
- Rest day / holiday, 5-day week: hours 1–8 = 2×, hour 9 = 3×, hours 10–12 = 4×.
- Limits: 4 h/day, 18 h/week (warn above 18 weekly).
- Wage base = base salary + fixed allowance.
- If country ≠ ID: replace with the local rule set from the Brief and note it in `ASSUMPTIONS.md`.
