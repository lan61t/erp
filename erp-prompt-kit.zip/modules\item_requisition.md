### Item Requisition (`item_requisition`) — CORE for goods businesses
- **Depends on:** sales_order, master_part
- **Default roles:** inventory, workshop_manager, owner, gm
- **Created:** only when stock is insufficient for an SO (FIFO shortfall, algorithm 9.1), or manually.
- **No prices shown.**
- **Items:** `{partNumber, qtyButuh, …, sudahDiPO}`.
- **Statuses:** `Menunggu Purchasing` → `Sudah di-PO` (when every item is allocated to some PO).
- **Rules**
  - Item-level quantity edit.
  - Shortage computed from the SO's exploded BOM (unit lines → components × qty; service lines skipped).
