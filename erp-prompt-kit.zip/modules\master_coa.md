### Expense Tag List / Master COA (`master_coa`) — OPTIONAL
- **Depends on:** none
- **Default roles:** owner, gm, finance_director
- **Purpose:** flat list of office operational cost accounts used to tag Operation Cost, other expenses, and exchange-rate differences in the journal.
- **Not linked to invoices.** Separate from the real chart of accounts in `laporan_keuangan`.
